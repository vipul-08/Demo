const express = require('express');
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/user');
const leaveRoutes = require('./routes/leave');
require('dotenv').config();

const app = express();
app.use(express.json());
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/leaves', leaveRoutes);

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
