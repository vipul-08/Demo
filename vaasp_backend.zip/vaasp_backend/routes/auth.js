const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const db = require('../db');
const router = express.Router();
require('dotenv').config();

const generateOtp = () => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

router.post('/signup', async (req,res) => {
    const { attuid, email, password, first_name, last_name, mobile, is_manager, manager_attuid } = req.body;
    if (!attuid || !email || !password || !first_name || !last_name || !mobile) {
        return res.status(400).json({ message: 'All fields are required' });
    }
    try {
        const [users] = await db.query(
            `SELECT * FROM users WHERE attuid = ?`,
            [attuid]
        );
        if (users.length > 0) {
            return res.status(409).json({ message: 'User already exists' });
        }
        const hashed = await bcrypt.hash(password, 10);
        await db.query(
            `INSERT INTO users (attuid, email, password, first_name, last_name, mobile, manager_attuid, is_manager) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [attuid, email, hashed, first_name, last_name, mobile, manager_attuid, is_manager ? 1 : 0]
        );
        await db.query(
            `INSERT INTO leave_balances (attuid) VALUES (?)`,
            [attuid]
        );
        res.status(201).json({ message: 'User created successfully' });
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
});

router.post('/login', async (req,res) => {
    const {email, password} = req.body;
    try {
        const [users] = await db.query('SELECT * FROM users WHERE email = ?', [email]);
        if (users.length === 0) {
            return res.status(401).json({ message: 'Invalid Credentials' });
        }
        const isValid = await bcrypt.compare(password, users[0].password);
        if (!isValid) {
            return res.status(401).json({ message: 'Invalid email or password' });
        }
        const token = jwt.sign({ id: users[0].attuid }, process.env.JWT_SECRET, { expiresIn: '1h' });
        const userInfo = {
            attuid: users[0].attuid,
            email: users[0].email,
            first_name: users[0].first_name,
            last_name: users[0].last_name,
            mobile: users[0].mobile,
            manager_attuid: users[0].manager_attuid,
            is_manager: users[0].is_manager
        };
        res.status(200).json({ message: 'Login successful', token, user: userInfo });
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
});

router.post('/send-otp', async (req, res) => {
    const { email } = req.body;
    if (!email) {
        return res.status(400).json({ message: 'Email is required' });
    }
    try {
        const otp = generateOtp();
        // Here you would send the OTP to the user's email
        console.log(`Sending OTP ${otp} to ${email}`);

        await db.query('DELETE FROM otps WHERE email = ?', [email]);
        await db.query('INSERT INTO otps (email, otp) VALUES (?, ?)', [email, otp]);

        res.status(200).json({ message: 'OTP sent successfully' });
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
});

router.post('/verify-otp', async (req,res) => {
    const { email, otp } = req.body;
    if (!email || !otp) {
        return res.status(400).json({ message: 'Email and OTP are required' });
    }
    try {
        const [rows] = await db.query('SELECT * FROM otps WHERE email = ? AND otp = ?', [email, otp]);
        if (rows.length === 0) {
            return res.status(401).json({ message: 'Invalid OTP' });
        }
        const createdAt = new Date(rows[0].created_at);
        const expiresAt = new Date(createdAt.getTime() + 5 * 60000); // OTP expires in 5 minutes
        if (expiresAt < new Date()) {
            return res.status(401).json({ message: 'OTP expired' });
        }
        await db.query('DELETE FROM otps WHERE email = ?', [email]);
        res.status(200).json({ message: 'OTP verified successfully' });
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
});

router.get('/hello', async (req, res) => {
    res.status(200).json({ message: 'Hello, world!' });
});

module.exports = router;