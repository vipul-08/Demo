const express = require('express');
const db = require('../db');
const router = express.Router();
require('dotenv').config();

const formatDate = (date) => {
    const options = { year: 'numeric', month: '2-digit', day: '2-digit' };
    return date.toLocaleDateString(undefined, options).split('/').reverse().join('/');
}

router.post('/check', async(req,res) => {
    const { attuid, leave_type, start_date, end_date } = req.body;
    const new_end_date = end_date === '' || end_date == null ? start_date : end_date;

    if (!attuid || !leave_type || !start_date) {
        return res.status(400).json({ message: 'All fields are required' });
    }

    try {
        const startDate = new Date(start_date);
        const endDate = new Date(new_end_date);

        let days = Math.floor((endDate - startDate) / (1000 * 60 * 60 * 24)) + 1;

        if (days <= 0) {
            return res.status(400).json({ message: 'Invalid date range' });
        }

        const checkExistingQuery = `SELECT * FROM leave_records WHERE attuid = ? and status != 'rejected' and start_date <= ? and end_date >= ?`;
        const [rows] = await db.query(checkExistingQuery, [attuid, new_end_date, start_date]);
        if (rows.length > 0) {
            return res.status(409).json({ message: 'Leave request overlaps with existing leave' });
        }

        const numPublicHolidaysQuery = `SELECT COUNT(*) from public_holidays WHERE date BETWEEN ? AND ?`;
        const [holidayRows] = await db.query(numPublicHolidaysQuery, [start_date, new_end_date]);
        const numPublicHolidays = holidayRows[0]['COUNT(*)'] || 0;

        days = days - numPublicHolidays;

        let final_start_date = startDate;
        let final_end_date = endDate;

        
        if (final_start_date.getDay() === 6) {
            final_start_date.setDate(final_start_date.getDate() + 2);
            days = days - 2;
        }
        else if (final_start_date.getDay() === 0) {
            final_start_date.setDate(final_start_date.getDate() + 1);
            days = days - 1;
        }

        if (final_end_date.getDay() === 6) {
            final_end_date.setDate(final_end_date.getDate() - 1);
            days = days - 1;
        }
        else if (final_end_date.getDay() === 0) {
            final_end_date.setDate(final_end_date.getDate() - 2);
            days = days - 2;
        }
        
        if (days <= 0) {
            return res.status(400).json({ message: 'Invalid date range' });
        }
    
        let counter = new Date(final_start_date);
        while (counter <= final_end_date) {
            const day = counter.getDay();
            if (day === 0 || day === 6) {
                days--;
            }
            counter.setDate(counter.getDate() + 1);
        }
        
        return res.status(200).json({ 
            start_date: formatDate(final_start_date),
            end_date: formatDate(final_end_date),
            numDays: days
        });

    } catch (error) {
        return res.status(500).json({ message: error.message });
    }

});

router.post('/apply', async (req, res) => {
    const { attuid, leave_type, start_date, end_date, reason } = req.body;
    const new_end_date = end_date === '' || end_date == null ? start_date : end_date;
    if (!attuid || !leave_type || !start_date) {
        return res.status(400).json({ message: 'All fields are required' });
    }
    try {
        const startDate = new Date(start_date);
        const endDate = new Date(new_end_date);

        const days = Math.floor((endDate - startDate) / (1000 * 60 * 60 * 24)) + 1;

        if (days <= 0) {
            return res.status(400).json({ message: 'Invalid date range' });
        }

        const [leaveBalanceRows] = await db.query(
            `SELECT * FROM leave_balances WHERE attuid = ?`,
            [attuid]
        );

        if (leaveBalanceRows.length === 0) {
            return res.status(404).json({ message: 'Leave balance not found' });
        }

        let row = leaveBalanceRows[0];
        if (row[leave_type] < days) {
            return res.status(400).json({ message: 'Insufficient leave balance for this leave type' });
        }

        await db.query(
            `UPDATE leave_balances SET ${leave_type} = ? WHERE attuid = ?`,
            [row[leave_type] - days, attuid]
        );

        await db.query(
            `INSERT INTO leave_records (attuid, leave_type, start_date, end_date, reason) VALUES (?, ?, ?, ?, ?)`,
            [attuid, leave_type, start_date, new_end_date, reason]
        );
        res.status(201).json({ message: 'Leave applied successfully' });
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
});

router.post('/approve', async (req,res) => {
    const { leave_id } = req.body;
    if (!leave_id) {
        return res.status(400).json({ message: 'Leave ID is required' });
    }
    try {
        await db.query(
            `UPDATE leave_records SET status = 'approved' WHERE id = ?`,
            [leave_id]
        );
        res.status(200).json({ message: 'Leave approved successfully' });
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
});

router.post('/decline', async (req, res) => {
    const { leave_id } = req.body;
    if (!leave_id) {
        return res.status(400).json({ message: 'Leave ID is required' });
    }
    try {

        const [leaveRecordRows] = await db.query(
            `SELECT * FROM leave_records WHERE id = ?`,
            [leave_id]
        );

        if (leaveRecordRows.length === 0) {
            return res.status(404).json({ message: 'Leave record not found' });
        }

        const { attuid, leave_type, start_date, end_date } = leaveRecordRows[0];

        const startDate = new Date(start_date);
        const endDate = new Date(end_date);

        const days = Math.floor((endDate - startDate) / (1000 * 60 * 60 * 24)) + 1;

        const [leaveBalanceRows] = await db.query(
            `SELECT * FROM leave_balances WHERE attuid = ?`,
            [attuid]
        );

        if (leaveBalanceRows.length === 0) {
            return res.status(404).json({ message: 'Leave balance not found' });
        }

        let row = leaveBalanceRows[0];

        await db.query(
            `UPDATE leave_balances SET ${leave_type} = ? WHERE attuid = ?`,
            [row[leave_type] + days, attuid]
        );

        await db.query(
            `UPDATE leave_records SET status = 'rejected' WHERE id = ?`,
            [leave_id]
        );
        res.status(200).json({ message: 'Leave declined successfully' });
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
});

router.get('/manager_list/:manager_id', async (req, res) => {
    const { manager_id } = req.params;
    const { leave_type } = req.query;
    const { status } = req.query;

    if (!manager_id) {
        return res.status(400).json({ message: 'Manager ID is required' });
    }
    try {
        const [employees_under_manager] = await db.query(
            `SELECT attuid, first_name FROM users WHERE manager_attuid = ?`,
            [manager_id]
        );

        const attuid_list = employees_under_manager.map(emp =>  emp.attuid);
        const idToName = employees_under_manager.reduce((a,c) =>  ({...a, [c.attuid]: c.first_name}), {});

        if (attuid_list.length === 0) {
            return res.status(404).json({ message: 'No direct reportees found' });
        }

        let query = 'SELECT * FROM leave_records WHERE attuid IN (?)';
        let params = [attuid_list];
        if (leave_type) {
            query += ' AND leave_type = ?';
            params.push(leave_type);
        }
        if (status) {
            query += ' AND status = ?';
            params.push(status);
        }
        const [leave_records] = await db.query(query, params);
        res.status(200).json(leave_records.map((record) => ({...record, firstName: idToName[record.attuid]})));
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
});

router.get('/my_list/:attuid', async (req, res) => {
    const { attuid } = req.params;
    const { leave_type } = req.query;
    const { status } = req.query;

    if (!attuid) {
        return res.status(400).json({ message: 'User ID is required' });
    }
    try {
        let query = 'SELECT * FROM leave_records WHERE attuid = ?';
        let params = [attuid];
        if (leave_type) {
            query += ' AND leave_type = ?';
            params.push(leave_type);
        }
        if (status) {
            query += ' AND status = ?';
            params.push(status);
        }
        const [leave_records] = await db.query(query, params);
        res.status(200).json(leave_records);
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
});

router.get('/balances/:attuid', async (req,res) => {
    const { attuid } = req.params;
    if (!attuid) {
        return res.status(400).json({ message: 'User ID is required' });
    }
    try {
        const [leave_balances] = await db.query(
            `SELECT * FROM leave_balances WHERE attuid = ?`,
            [attuid]
        );
        res.status(200).json(leave_balances[0]);
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
});

module.exports = router;