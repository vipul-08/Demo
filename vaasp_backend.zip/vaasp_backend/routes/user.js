const express = require('express');
const db = require('../db');
const router = express.Router();
require('dotenv').config();

router.get('/', async (req, res) => {
    // Determine if only managers should be queried
    const searchOnlyManager = req.query.manager === '1';
    try {
        let users;
        if (searchOnlyManager) {
            // Query only managers
            users = await db.query('SELECT * FROM users WHERE is_manager = 1');
        } else {
            // Query all users
            users = await db.query('SELECT * FROM users');
        }
        res.status(200).json(users[0]);
    } catch (err) {
        res.status(500).json({ error: 'Database error', details: err.message });
    }
});

module.exports = router;