# VAASP_BACKEND

## Completed Endpoints

- POST /api/auth/login
- POST /api/auth/signup
- POST /api/auth/send-otp
- POST /api/auth/verify-otp

- GET /api/leaves/my_list/{attuid}
- GET /api/leaves/manager_list/{attuid}
- GET /api/leaves/balances/{attuid}
- POST /api/leaves/apply
- POST /api/leaves/approve
- POST /api/leaves/decline

- GET /api/users

## Installation Instructions
- Have node and npm installed in the system
- RUN npm install to install all dependencies
- RUN npm start to start the backend