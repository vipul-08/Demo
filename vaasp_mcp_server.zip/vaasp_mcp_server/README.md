# MCP Server with Uvicorn API
- Need to have python3 and uvicorn installed
- Need to have python packages - [mcp, requests, json, fastapi, pydantic]
- RUN Command: uvicorn server:app --host 0.0.0.0 --port 3000 --reload