from fastapi import FastAPI
from pydantic import BaseModel
import uvicorn
import json

from main import(
    get_leave_balance,
    check_leave_history,
    check_leave_history_manager,
    apply_leave,
    chat_with_ai
)

app = FastAPI(title = "Leave Management API")

class ChatRequest(BaseModel):
    user_message: str
    attuid: str

class ApplyLeaveRequest(BaseModel):
    attuid: str
    leave_type: str
    start_date: str
    end_date: str
    reason: str

@app.post("/chat")
def chat_server(request: ChatRequest):
    return chat_with_ai(request.user_message, request.attuid)

@app.post("/apply_leave")
def apply_leave_server(request: ApplyLeaveRequest):
    return apply_leave(
        request.attuid,
        request.leave_type,
        request.start_date,
        request.end_date,
        request.reason
    )

@app.get("/leave_balance/{attuid}")
def get_leave_balance_server(attuid: str):
    return get_leave_balance(attuid)

@app.get("/leave_history/{attuid}")
def get_leave_history_server(attuid: str):
    return check_leave_history(attuid)

@app.get("/leave_history_manager/{manager_id}")
def get_leave_history_manager_server(manager_id: str):
    return check_leave_history_manager(manager_id)


if __name__ == "__main__":
    uvicorn.run("server:app", host="0.0.0.0", port=3000, reload=True)