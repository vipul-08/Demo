from mcp.server.fastmcp import FastMCP
from typing import Dict, Any
import requests
import json
from datetime import datetime

server = FastMCP("LeaveManagementAI")

VALID_LEAVE_TYPES = ["sick", "vacation", "casual"]

API_URL = "http://localhost:5000/api"

# ----------------------------------- Tools -----------------------------------

@server.tool()
def get_leave_balance(attuid: str) -> Dict[str, Any]:
    url = f"{API_URL}/leaves/balances/{attuid}"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        leave_bal = {
            "sick": data["sick"],
            "casual": data["casual"],
            "vacation": data["vacation"]
        }
        return {"attuid": attuid, "balance": leave_bal}
    return {"attuid": attuid, "error": f"Error fetching leave balance for Employee {attuid}"}

@server.tool()
def get_leave_balance_sick(attuid: str) -> Dict[str, Any]:
    response = get_leave_balance(attuid)
    return {"attuid": attuid, "sick_balance": response["balance"].get("sick", 0)}

@server.tool()
def get_leave_balance_casual(attuid: str) -> Dict[str, Any]:
    response = get_leave_balance(attuid)
    return {"attuid": attuid, "casual_balance": response["balance"].get("casual", 0)}

@server.tool()
def get_leave_balance_vacation(attuid: str) -> Dict[str, Any]:
    response = get_leave_balance(attuid)
    return {"attuid": attuid, "vacation_balance": response["balance"].get("vacation", 0)}

@server.tool()
def check_leave_history(attuid: str) -> Dict[str, Any]:
    url = f"{API_URL}/leaves/my_list/{attuid}"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        return {"attuid": attuid, "history": data}
    return {"attuid": attuid, "error": f"Error fetching leave history for Employee {attuid}"}

@server.tool()
def check_leave_history_manager(attuid: str) -> Dict[str, Any]:
    url = f"{API_URL}/leaves/manager_list/{attuid}"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        return {"manager_attuid": attuid, "history": data}
    return {"manager_attuid": attuid, "error": f"Error fetching leave history for Manager {attuid}"}

@server.tool()
def apply_leave(attuid: str, leave_type: str, start_date: str, end_date: str, reason: str) -> Dict[str, Any]:
    url = f"{API_URL}/leaves/apply"
    payload = {
        "attuid": attuid,
        "leave_type": leave_type,
        "start_date": start_date,
        "end_date": end_date,
        "reason": reason
    }

    response = requests.post(url, json=payload)
    if response.status_code == 201:
        data = response.json()
        return {"attuid": attuid, "status": "Leave applied successfully"}
    return {"attuid": attuid, "error": f"Error applying for leave: {response.text}"}

OLLAMA_API = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "deepseek-coder-v2"
# OLLAMA_MODEL = "gpt-oss:20b"

@server.tool()
def chat_with_ai(user_message: str, attuid: str) -> Dict[str, str]:
    """
    AI assisstant that decides which MCP Tool to call using OLLAMA
    """
    
    system_prompt = f"""
    You are an AI Leave Management Assisstant
    You have the following tools:

    1. get_leave_balance(attuid: str) -> returns leave balances
    2. get_leave_balance_sick(attuid: str) -> returns sick leave balance
    3. get_leave_balance_casual(attuid: str) -> returns casual leave balances
    4. get_leave_balance_vacation(attuid: str) -> returns vacation leave balances
    5. check_leave_history(attuid: str) -> returns leave history
    6. check_leave_history_manager(attuid: str) -> returns leave history for people under manager with attuid
    7. apply_leave(attuid: str, leave_type: str, start_date: str, end_date: str, reason: str) -> applies for leave

    Valid Leave Types:
    - sick
    - vacation
    - casual

    Rules:
    - If user asks for leave balance, tool used will be get_leave_balance
    - If user asks for sick leave balance, tool used will be get_leave_balance_sick
    - If user asks for casual leave balance, tool used will be get_leave_balance_casual
    - If user asks for vacation leave balance, tool used will be get_leave_balance_vacation
    - If user asks for leave history, tool used will be check_leave_history
    - If user asks for leave history of his team, tool used will be check_leave_history_manager
    - If user wants to apply for leave, tool used will be apply_leave
    - Otherwise, reply conversationally
    - Always return a json in this structure:
      {{ "action": "tool"|"answer", "name": "tool_name_if_any", "args": {{}}, "text": "your response text" }}
    """
    print("Hello")
    response = requests.post(
        OLLAMA_API,
        json={"model": OLLAMA_MODEL, "stream": False, "prompt": system_prompt + "\nUser: For employee ID: " + attuid + ", " + user_message}
    )

    if response.status_code != 200:
        return {"response": "AI Service Unavailable"}
    
    try:
        decision = json.loads(response.json()["response"].strip().removeprefix("```json").removesuffix("```").strip())
    except Exception:
        return {"response": "AI returned invalid response"}

    if decision.get("action") == "tool":
        tool_name = decision.get("name")
        tool_args = decision.get("args", {})

        if tool_name == "get_leave_balance":
            result =  get_leave_balance(attuid)
        elif tool_name == "get_leave_balance_sick":
            result = get_leave_balance_sick(attuid)
        elif tool_name == "get_leave_balance_casual":
            result = get_leave_balance_casual(attuid)
        elif tool_name == "get_leave_balance_vacation":
            result = get_leave_balance_vacation(attuid)
        elif tool_name == "check_leave_history":
            result = check_leave_history(attuid)
        elif tool_name == "check_leave_history_manager":
            result = check_leave_history_manager(attuid)
        elif tool_name == "apply_leave":
            result = apply_leave(attuid, tool_args.get("leave_type", ""), tool_args.get("start_date", ""), tool_args.get("end_date", ""), tool_args.get("reason", ""))
        else:
            result = {"error": "Unknown Tool"}
        return {
            "decision": decision,
            "result": result
        }
    return {
        "decision": decision
    }

if __name__ == "__main__":
    server.run()
