from flask import Flask, request, jsonify
from roster_generator import generate_next_month_roster, reassign_shifts_for_leave, get_employee_roster, get_manager_roster, get_employee_preferences, add_employee_preferences

app = Flask(__name__)

@app.route('/hello')
def hello_world():
    return 'Hello, World!'


@app.route("/generate_roster", methods=["POST"])
def generate_roster():
    try:
        data = request.get_json()
        manager_id = data.get("manager_id")
        year = data.get("year")
        month = data.get("month")

        if not manager_id:
            return jsonify({"status": "error", "message": "manager_id is required"}), 400
        
        if not year:
            return jsonify({"status": "error", "message": "year is required"}), 400

        if not month:
            return jsonify({"status": "error", "message": "month is required"}), 400

        result = generate_next_month_roster(manager_id, int(year), int(month))
        return jsonify(result)
    except Exception as e:
        print("Error:", e)
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route("/reassign_roster", methods=["POST"])
def reassign_roster():
    try:
        data = request.get_json()
        manager_id = data.get("manager_id")
        leave_date = data.get("leave_date")
        employee_id = data.get("employee_id")

        if not manager_id:
            return jsonify({"status": "error", "message": "manager_id is required"}), 400
        
        if not leave_date:
            return jsonify({"status": "error", "message": "leave_date is required"}), 400

        if not employee_id:
            return jsonify({"status": "error", "message": "employee_id is required"}), 400

        result = reassign_shifts_for_leave(manager_id, leave_date, employee_id)
        return jsonify(result)
    except Exception as e:
        print("Error:", e)
        return jsonify({"status": "error", "message": str(e)}), 500
    
@app.route("/add_preference", methods=["POST"])
def add_preferrence():
    try:
        data = request.get_json()
        
        manager_id = data.get("manager_id")
        employee_id = data.get("employee_id")
        
        month = data.get("month")
        year = data.get("year")

        preferred_shifts = data.get("preferred_shifts", [])
        preferred_weekday = data.get("preferred_weekday", {})
        preferred_days = data.get("preferred_days", {})
        unavailable_days = data.get("unavailable_days", [])


        if not manager_id:
            return jsonify({"status": "error", "message": "manager_id is required"}), 400
        
        if not employee_id:
            return jsonify({"status": "error", "message": "employee_id is required"}), 400

        if not month:
            return jsonify({"status": "error", "message": "month is required"}), 400

        if not year:
            return jsonify({"status": "error", "message": "year is required"}), 400

        if not preferred_shifts:
            return jsonify({"status": "error", "message": "preferred_shifts is required"}), 400

        if not preferred_weekday:
            return jsonify({"status": "error", "message": "preferred_weekday is required"}), 400

        if not preferred_days:
            return jsonify({"status": "error", "message": "preferred_days is required"}), 400

        if not unavailable_days:
            return jsonify({"status": "error", "message": "unavailable_days is required"}), 400

        result = add_employee_preferences(manager_id, employee_id, month, year, preferred_shifts, preferred_weekday, preferred_days, unavailable_days)
        return jsonify(result)
    except Exception as e:
        print("Error:", e)
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route("/employee_roster", methods=["GET"])
def getEmployeeRoster():
    employee_id = request.args.get("employee_id")
    manager_id = request.args.get("manager_id")
    month = request.args.get("month")
    year = request.args.get("year")

    if not employee_id:
        return jsonify({"status": "error", "message": "employee_id is required"}), 400

    if not manager_id:
        return jsonify({"status": "error", "message": "manager_id is required"}), 400

    if not month:
        return jsonify({"status": "error", "message": "month is required"}), 400

    if not year:
        return jsonify({"status": "error", "message": "year is required"}), 400

    # Call the function to get the employee roster
    result = get_employee_roster(employee_id, manager_id, int(month), int(year))
    if result == None:
        return jsonify({"status": "error", "message": "No roster found for the specified employee and date range."}), 404
    else:
        return jsonify({
            "status": "success",
            "employee_id": employee_id,
            "data": result
        })

@app.route("/employee_preferences", methods=["GET"])
def getEmployeePreferences():
    employee_id = request.args.get("employee_id")
    manager_id = request.args.get("manager_id")
    month = request.args.get("month")
    year = request.args.get("year")

    if not employee_id:
        return jsonify({"status": "error", "message": "employee_id is required"}), 400

    if not manager_id:
        return jsonify({"status": "error", "message": "manager_id is required"}), 400

    if not month:
        return jsonify({"status": "error", "message": "month is required"}), 400

    if not year:
        return jsonify({"status": "error", "message": "year is required"}), 400

    # Call the function to get the employee preferences
    result = get_employee_preferences(employee_id, manager_id, int(month), int(year))
    if result == None:
        return jsonify({"status": "error", "message": "No preferences found for the specified employee and date range."}), 404
    else:
        return jsonify({
            "status": "success",
            "employee_id": employee_id,
            "data": result
        })

@app.route("/manager_roster", methods=["GET"])
def getManagerRoster():
    manager_id = request.args.get("manager_id")
    month = request.args.get("month")
    year = request.args.get("year")

    if not manager_id:
        return jsonify({"status": "error", "message": "manager_id is required"}), 400

    if not month:
        return jsonify({"status": "error", "message": "month is required"}), 400

    if not year:
        return jsonify({"status": "error", "message": "year is required"}), 400

    # Call the function to get the employee roster
    result = get_manager_roster(manager_id, int(month), int(year))

    if result == None:
        return jsonify({"status": "error", "message": "No roster found for the specified manager and date range."}), 404
    else:
        return jsonify({
            "status": "success",
            "manager_id": manager_id,
            "data": result
        })

if __name__ == '__main__':
    app.run(debug=True, port=5050)