import os
import json
from pymongo import MongoClient

mongo_uri = "mongodb://localhost:27017/"
client = MongoClient(mongo_uri)
db = client["vaasp_ai"]

dir = "/Users/vr7663/Downloads/SS863T"

for filename in os.listdir(dir):
    file_path = os.path.join(dir, filename)
    if os.path.isfile(file_path) and filename.endswith(".json"):
        with open(file_path, "r", encoding="utf-8") as file :
            data = json.load(file)
            coll_name = os.path.splitext(filename)[0]
            db[coll_name].insert_many(data)
            